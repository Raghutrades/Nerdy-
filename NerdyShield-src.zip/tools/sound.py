#!/usr/bin/env python3
"""Synthesises the NerdyShield launch score (7 s, stereo): sub drone, rising riser, heartbeat ticks, a big impact at 3.2 s,
bell shimmer, then a resolving pad. Pure numpy/scipy, no samples, so it is 100% original.
Usage: python tools/sound.py [out.wav]   (CI does not need this: overlay/assets/shield/intro.ogg is already generated)"""
import sys
import numpy as np
from scipy.io import wavfile
from scipy.signal import fftconvolve, butter, lfilter

SR, DUR = 32000, 7.0
N = int(SR * DUR)
t = np.arange(N) / SR
rng = np.random.default_rng(7)


def env(t0, a, d, length=None):
    """attack/decay envelope starting at t0 (seconds)."""
    e = np.zeros(N)
    i0 = int(t0 * SR)
    n = N - i0 if length is None else min(int(length * SR), N - i0)
    x = np.arange(n) / SR
    e[i0:i0 + n] = np.minimum(x / max(a, 1e-4), 1.0) * np.exp(-x / d)
    return e


def lp(x, hz):
    b, a = butter(2, hz / (SR / 2))
    return lfilter(b, a, x)


def hp(x, hz):
    b, a = butter(2, hz / (SR / 2), btype="high")
    return lfilter(b, a, x)


mix = np.zeros(N)

# 1) sub drone: A1 + E2, swelling to the impact, then easing
swell = np.interp(t, [0, 1.0, 3.2, 4.5, 7.0], [0.0, 0.35, 1.0, 0.55, 0.25])
drone = np.sin(2 * np.pi * 55 * t) + 0.5 * np.sin(2 * np.pi * 82.41 * t + 0.4) + 0.25 * np.sin(2 * np.pi * 110.3 * t)
for h in range(1, 9):  # a dark detuned saw layer, low-passed by amplitude roll-off
    drone += 0.35 / h * np.sin(2 * np.pi * 55.4 * h * t + h)
mix += 0.30 * swell * drone

# 2) riser 0.3 -> 3.2 s: exponential chirp + rising noise
rt = np.clip((t - 0.3) / 2.9, 0, 1)
f = 180 * (2600 / 180) ** rt
ph = 2 * np.pi * np.cumsum(f) / SR
ramp = rt ** 2.2 * (t < 3.2)
mix += 0.16 * ramp * (np.sin(ph) + 0.6 * np.sin(ph * 1.5 + 1))
mix += 0.30 * ramp * hp(rng.standard_normal(N), 1500) * 0.35

# 3) heartbeat ticks that accelerate toward the hit
for k, tt in enumerate([0.9, 1.45, 1.95, 2.35, 2.68, 2.93, 3.07]):
    e = env(tt, 0.004, 0.11, 0.5)
    fr = 95 * np.exp(-np.maximum(t - tt, 0) * 14) + 38
    mix += (0.55 + 0.05 * k) * e * np.sin(2 * np.pi * np.cumsum(fr) / SR)

# 4) impact at 3.2 s: pitch-dropping boom + noise burst + sub tail
T0 = 3.2
bt = np.maximum(t - T0, 0)
boom = env(T0, 0.003, 1.15, 4) * np.sin(2 * np.pi * np.cumsum(30 + 110 * np.exp(-bt * 7)) / SR)
mix += 1.35 * boom
mix += 0.55 * env(T0, 0.001, 0.22, 1) * lp(rng.standard_normal(N), 4500)
mix += 0.35 * env(T0, 0.002, 1.4, 3) * lp(rng.standard_normal(N), 700)

# 5) bell shimmer on the hit (inharmonic partials: A5 / E6 / A6 / C#7 area)
for fr, g, dk in [(880, .20, 2.1), (1318.5, .13, 1.8), (1760, .10, 1.6), (2217.5, .07, 1.3), (2637, .05, 1.0), (3520, .03, .8)]:
    mix += g * env(T0 + 0.01, 0.002, dk, 4) * np.sin(2 * np.pi * fr * t)
    mix += 0.5 * g * env(T0 + 0.01, 0.002, dk, 4) * np.sin(2 * np.pi * fr * 2.76 * t)

# 6) resolving pad (A major add9) fading in after the hit
pad = np.zeros(N)
for fr in (110, 164.81, 220, 277.18, 329.63, 493.88):
    for dt in (-0.6, 0.0, 0.7):
        pad += np.sin(2 * np.pi * (fr + dt) * t + fr)
pad *= np.interp(t, [0, 3.2, 4.0, 5.8, 7.0], [0, 0, 0.9, 0.7, 0.0])
mix += 0.05 * pad

# 7) a soft rising arpeggio tail (A, C#, E, A) for the tagline
for k, (fr, tt) in enumerate([(440, 4.2), (554.37, 4.45), (659.25, 4.7), (880, 4.95)]):
    mix += 0.07 * env(tt, 0.01, 0.9, 2) * np.sin(2 * np.pi * fr * t)

# stereo reverb: two different decaying-noise impulse responses
ir_len = int(1.7 * SR)
x = np.arange(ir_len) / SR
irL = rng.standard_normal(ir_len) * np.exp(-x * 3.0)
irR = rng.standard_normal(ir_len) * np.exp(-x * 3.0)
irL /= np.abs(irL).sum() ** 0.5 * 14
irR /= np.abs(irR).sum() ** 0.5 * 14
dry = mix
wetL = fftconvolve(dry, irL)[:N]
wetR = fftconvolve(dry, irR)[:N]
L = dry * 0.78 + wetL * 0.55
R = dry * 0.78 + wetR * 0.55
# gentle stereo width on the shimmer: tiny delay on R
d = int(0.011 * SR)
R = np.concatenate([np.zeros(d), R[:-d]])

fade = np.clip((DUR - 0.15 - t) / 0.85, 0, 1) ** 1.5 * np.clip(t / 0.05, 0, 1)
L *= fade
R *= fade
peak = max(np.abs(L).max(), np.abs(R).max())
g = 0.89 / peak
out = (np.stack([L, R], 1) * g * 32767).astype(np.int16)
dst = sys.argv[1] if len(sys.argv) > 1 else "intro.wav"
wavfile.write(dst, SR, out)
print("wrote", dst, f"{DUR}s", SR, "Hz stereo")
