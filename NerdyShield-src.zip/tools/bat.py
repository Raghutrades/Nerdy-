"""Single source of truth for the NerdyShield bat shape (Batman-signal style, original drawing).
Coordinates: x -48..48, y -20..20, centre (0,0). Used for the launcher icon, vector drawable, splash and hub."""
START = (0, -9)
# right half, top-centre clockwise to bottom-centre: ('L',(x,y)) or ('Q',(cx,cy),(x,y))
RIGHT = [
    ('L', (2.2, -9)), ('L', (3.9, -18)), ('L', (6.6, -9.4)),
    ('Q', (14, -11.5), (24, -15)),
    ('Q', (37, -14.5), (48, -6.5)),
    ('Q', (42, -5.5), (38, 3.6)),
    ('Q', (33.5, -1.6), (28.5, -1)),
    ('Q', (26.5, 2.5), (25.5, 8.2)),
    ('Q', (20.5, 2.6), (15.5, 2.4)),
    ('Q', (13.2, 4.6), (12, 10)),
    ('Q', (8.2, 4.4), (4.6, 5.2)),
    ('L', (0, 18)),
]
def _m(p): return (-p[0], p[1])
def segments():
    segs = [(t[0], t[1] if t[0] == 'Q' else None, t[-1]) for t in RIGHT]
    anchors = [START] + [s[2] for s in segs]
    left = []
    for i in range(len(segs) - 1, -1, -1):
        t, c, _ = segs[i]
        left.append((t, _m(c) if c else None, _m(anchors[i])))
    return segs + left
def path_d(scale=1.0, ox=0.0, oy=0.0, nd=2):
    f = lambda p: f"{p[0]*scale+ox:.{nd}f},{p[1]*scale+oy:.{nd}f}"
    d = "M" + f(START)
    for t, c, e in segments():
        d += (f" L{f(e)}" if t == 'L' else f" Q{f(c)} {f(e)}")
    return d + " Z"
def polygon(scale=1.0, ox=0.0, oy=0.0, steps=14):
    pts = [(START[0]*scale+ox, START[1]*scale+oy)]; cur = START
    for t, c, e in segments():
        if t == 'L': pts.append((e[0]*scale+ox, e[1]*scale+oy))
        else:
            for k in range(1, steps + 1):
                u = k / steps
                x = (1-u)**2*cur[0] + 2*(1-u)*u*c[0] + u*u*e[0]
                y = (1-u)**2*cur[1] + 2*(1-u)*u*c[1] + u*u*e[1]
                pts.append((x*scale+ox, y*scale+oy))
        cur = e
    return pts
if __name__ == "__main__":
    from PIL import Image, ImageDraw
    im = Image.new("RGB", (640, 360), "#FFC400"); d = ImageDraw.Draw(im)
    W, H = im.size; d.ellipse([W*.12, H*.1, W*.88, H*.9], fill="#FFE55C", outline="#1b1f2a", width=10)
    d.polygon(polygon(6.0, W/2, H/2), fill="#1b1f2a"); im.save("/home/claude/bat_preview.png")
