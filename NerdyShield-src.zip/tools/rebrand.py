#!/usr/bin/env python3
"""NerdyShield rebrand: takes the OFFICIAL Orbot APK and produces NerdyShield.apk.
 name -> NerdyShield | bat icon | cinematic splash | hub with menus + About page | re-signed with your key.
Usage: rebrand.py <orbot.apk> <apktool.jar> <out.apk>        (run by .github/workflows/build-shield.yml)"""
import glob, os, pathlib, re, shutil, subprocess, sys, zipfile
from lxml import etree
from PIL import Image, ImageDraw, ImageFilter

HERE = pathlib.Path(__file__).resolve().parent
ROOT = HERE.parent
sys.path.insert(0, str(HERE))
import bat

NAME = "NerdyShield"
NS_PKG = "com.nerdyintruder.nerdyshield"
ANS = "http://schemas.android.com/apk/res/android"
A = "{%s}" % ANS
INK, AMBER, YELLOW = "#1B1F2A", "#F5B700", "#FFE55C"
KS = os.environ.get("KS_FILE", str(ROOT / "keystore" / "nerdyshield.jks"))
KS_PASS = os.environ.get("KS_PASS", "nerdyshield")
KS_ALIAS = os.environ.get("KS_ALIAS", "nerdyshield")


def sh(cmd, **kw):
    print("+", " ".join(str(c) for c in cmd), flush=True)
    return subprocess.run([str(c) for c in cmd], check=True, **kw)


# ---------------------------------------------------------------- strings
# Words that are replaced in text people can read. URLs, .onion addresses, class names and @refs are never touched.
SKIP = re.compile(r"(https?://\S+|\S*\.onion\S*|\S*org\.torproject\S*|\S*torproject\.org\S*|@\w*:?\w+/\w+|%\d\$[sd]|%[sd])")
WORDS = [
    (r"\bThe Tor Project\b", NAME), (r"\bTor Project\b", NAME), (r"\bThe Guardian Project\b", NAME), (r"\bGuardian Project\b", NAME),
    (r"\bTor Browser\b", "a private browser"), (r"\bOrbot\b", NAME), (r"\bOrbie\b", "Shield"),
    (r"\bTOR\b", NAME.upper()), (r"\bTor\b", NAME),
]
WORDS = [(re.compile(p), r) for p, r in WORDS]


def brand_text(text):
    # lines separated by a literal backslash-n (resource files) or a real newline are handled one by one,
    # so a lone "Tor" / "Orbot" line gets a SHORT label ("Core" / "Shield") and monospace columns stay aligned
    if "\\n" in text or "\n" in text:
        sep = "\\n" if "\\n" in text else "\n"
        return sep.join(brand_text(p) for p in text.split(sep))
    st = text.strip()
    if st in ("Tor", "TOR"):
        return text.replace(st, "Core")
    if st == "Orbot":
        return text.replace(st, "Shield")
    parts = SKIP.split(text)
    out = []
    for i, part in enumerate(parts):
        if SKIP.fullmatch(part or ""):
            out.append(part)
            continue
        for rx, rep in WORDS:
            part = rx.sub(rep, part)
        out.append(part)
    return "".join(out)


def patch_strings(work):
    n_app = n_txt = 0
    pat = re.compile(r'(<(?:string|item)\b[^>]*>)([^<]*)(</(?:string|item)>)', re.S)

    def fix(m):
        nonlocal n_app, n_txt
        head, text, tail = m.groups()
        if 'name="app_name"' in head:
            n_app += 1
            return head + NAME + tail
        new = brand_text(text)
        if new != text:
            n_txt += 1
            return head + new + tail
        return m.group(0)

    for f in glob.glob(str(work / "res" / "values*" / "*.xml")):
        if os.path.basename(f) in ("public.xml", "ids.xml", "attrs.xml"):
            continue
        s = open(f, encoding="utf-8").read()
        t = pat.sub(fix, s)
        if t != s:
            open(f, "w", encoding="utf-8").write(t)
    print(f"strings: app_name x{n_app}, visible Orbot/Tor wording rewritten in x{n_txt} strings")
    if n_app == 0:
        print("WARNING: no app_name string found; the launcher label may stay as the old name")


def patch_manifest_labels(work):
    mf = work / "AndroidManifest.xml"
    s = mf.read_text(encoding="utf-8")
    n = s
    n = re.sub(r'(android:(?:label|description)=")([^"@][^"]*)(")', lambda m: m.group(1) + brand_text(m.group(2)) + m.group(3), n)
    if n != s:
        mf.write_text(n, encoding="utf-8")
        print("manifest: literal labels rebranded")


# ---------------------------------------------------------------- donate removal
def patch_donate(work):
    """Hides every Donate row/button/menu item/preference. (Code is untouched, so nothing can crash on a missing view.)"""
    AUTO = "http://schemas.android.com/apk/res-auto"
    rx = re.compile(r"donat", re.I)
    hidden = {"layout": 0, "menu": 0, "pref": 0}
    for f in glob.glob(str(work / "res" / "layout*" / "*.xml")) + glob.glob(str(work / "res" / "menu*" / "*.xml")) + glob.glob(str(work / "res" / "xml*" / "*.xml")):
        try:
            tree = etree.parse(f)
        except Exception:
            continue
        changed = False
        kind = "menu" if "/menu" in f else ("pref" if "/xml" in f else "layout")
        for el in tree.iter():
            if not isinstance(el.tag, str):
                continue
            vals = [el.get(A + "id") or "", el.get(A + "text") or "", el.get(A + "title") or "", el.get(A + "contentDescription") or "",
                    el.get(A + "key") or "", el.get("{%s}title" % AUTO) or "", el.get("{%s}key" % AUTO) or ""]
            if not any(rx.search(v) for v in vals):
                continue
            if kind == "menu":
                el.set(A + "visible", "false")
                el.set(A + "enabled", "false")
            elif kind == "pref":
                el.set("{%s}isPreferenceVisible" % AUTO, "false")
            else:
                el.set(A + "visibility", "gone")
            hidden[kind] += 1
            changed = True
        if changed:
            tree.write(f, xml_declaration=True, encoding="utf-8")
    print("donate hidden:", hidden)
    if not any(hidden.values()):
        print("WARNING: no donate views found in resources; check the decoded layouts")


# ---------------------------------------------------------------- remaining brand drawables
def patch_nav(work):
    """Bottom bar: Connect tab gets the bat icon; the heart tab (Kindness / donate-style) is removed.
    Items are found by id/title/icon words, and every item found is printed in the build log."""
    write(work / "res/drawable/nerdyshield_nav_bat.xml", f'''<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="{ANS}" android:width="30dp" android:height="22.5dp" android:viewportWidth="108" android:viewportHeight="81">
  <path android:fillColor="{GOLD}" android:fillType="evenOdd" android:pathData="M4,40.5 a50,36 0 1,0 100,0 a50,36 0 1,0 -100,0 Z {bat.path_d(0.78, 54, 40.5)}"/>
</vector>''')
    heart = re.compile(r"kindness|heart|donat|snowflake|favou?rite", re.I)
    conn = re.compile(r"connect|home|main", re.I)
    done = {"hidden": 0, "icon": 0}
    for f in glob.glob(str(work / "res" / "menu*" / "*.xml")):
        try:
            tree = etree.parse(f)
        except Exception:
            continue
        items = [e for e in tree.iter("item")]
        if not items:
            continue
        info = [(e.get(A + "id") or "", e.get(A + "title") or "", e.get(A + "icon") or "") for e in items]
        print("  menu", os.path.basename(f), info)
        if not any(heart.search(" ".join(i)) for i in info):
            continue
        ch = False
        first_visible = None
        for e, i in zip(items, info):
            blob = " ".join(i)
            if heart.search(blob):
                e.set(A + "visible", "false")
                e.set(A + "enabled", "false")
                done["hidden"] += 1
                ch = True
            elif first_visible is None:
                first_visible = (e, i)
        target = None
        for e, i in zip(items, info):
            if not heart.search(" ".join(i)) and conn.search(" ".join(i[:2])):
                target = e
                break
        if target is None and first_visible:
            target = first_visible[0]
        if target is not None:
            target.set(A + "icon", "@drawable/nerdyshield_nav_bat")
            done["icon"] += 1
            ch = True
        if ch:
            tree.write(f, xml_declaration=True, encoding="utf-8")
    print("nav patched:", done)
    if not done["hidden"] or not done["icon"]:
        print("WARNING: could not find the bottom-bar menu items; see the menu lines above")


def _vec(body):
    return f'''<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="{ANS}" android:width="24dp" android:height="24dp" android:viewportWidth="24" android:viewportHeight="24">{body}</vector>'''


def _S(d, c="#FFE08A", w=1.7):
    return f'<path android:pathData="{d}" android:strokeColor="{c}" android:strokeWidth="{w}" android:strokeLineCap="round" android:strokeLineJoin="round"/>'


def _F(d, c="#FFE08A"):
    return f'<path android:pathData="{d}" android:fillColor="{c}"/>'


CY = "#7FDBFF"
ICON_SET = {
    "ic_choose_apps": _S("M4.5,4.5 H10 V10 H4.5 Z") + _S("M14,4.5 H19.5 V10 H14 Z") + _S("M4.5,14 H10 V19.5 H4.5 Z") + _S("M16.75,14 V19.5 M14,16.75 H19.5", CY),
    "ic_shield": _S("M12,3 L19.5,6 V11.5 C19.5,16.2 16.4,19.6 12,21 C7.6,19.6 4.5,16.2 4.5,11.5 V6 Z") + _S("M8.6,12.2 L11,14.6 L15.6,9.8", CY),
    "lock_24px": _S("M5.5,10.5 H18.5 V19.5 H5.5 Z") + _S("M8,10.5 V8 A4,4 0 0 1 16,8 V10.5") + _F("M10.7,15 a1.3,1.3 0 1,0 2.6,0 a1.3,1.3 0 1,0 -2.6,0 Z", CY),
    "ic_vpn_key": _S("M4.5,12 a3.6,3.6 0 1,0 7.2,0 a3.6,3.6 0 1,0 -7.2,0 Z") + _S("M11.7,12 H20 M17.2,12 V15 M20,12 V14.4") + _F("M7.1,12 a1,1 0 1,0 2,0 a1,1 0 1,0 -2,0 Z", CY),
    "ic_settings_gear": _S("M4,7 H7 M11,7 H20 M4,12 H13 M17,12 H20 M4,17 H6 M10,17 H20") + _S("M7,7 a2,2 0 1,0 4,0 a2,2 0 1,0 -4,0 Z", CY) + _S("M13,12 a2,2 0 1,0 4,0 a2,2 0 1,0 -4,0 Z", CY) + _S("M6,17 a2,2 0 1,0 4,0 a2,2 0 1,0 -4,0 Z", CY),
    "ic_log": _S("M4,5.5 H20 V18.5 H4 Z") + _S("M7.5,9.8 L10.6,12 L7.5,14.2 M12.4,14.4 H16.6", CY),
    "ic_onion": _S("M5,4.5 H19 V10 H5 Z") + _S("M5,14 H19 V19.5 H5 Z") + _F("M7.1,7.25 a0.9,0.9 0 1,0 1.8,0 a0.9,0.9 0 1,0 -1.8,0 Z", CY) + _F("M7.1,16.75 a0.9,0.9 0 1,0 1.8,0 a0.9,0.9 0 1,0 -1.8,0 Z", CY) + _S("M11.5,7.25 H16 M11.5,16.75 H16 M12,10 V14"),
    "ic_about": _S("M3.5,12 a8.5,8.5 0 1,0 17,0 a8.5,8.5 0 1,0 -17,0 Z") + _S("M12,11 V16.2") + _F("M11,8 a1,1 0 1,0 2,0 a1,1 0 1,0 -2,0 Z", CY),
    "ic_generic_info": _S("M3.5,12 a8.5,8.5 0 1,0 17,0 a8.5,8.5 0 1,0 -17,0 Z") + _S("M12,11 V16.2") + _F("M11,8 a1,1 0 1,0 2,0 a1,1 0 1,0 -2,0 Z", CY),
    "ic_faq": _S("M3.5,12 a8.5,8.5 0 1,0 17,0 a8.5,8.5 0 1,0 -17,0 Z") + _S("M9.6,9.6 C9.8,8.3 10.8,7.6 12,7.6 C13.3,7.6 14.3,8.4 14.3,9.5 C14.3,10.9 12,11.1 12,13.2") + _F("M11.1,16.2 a0.9,0.9 0 1,0 1.8,0 a0.9,0.9 0 1,0 -1.8,0 Z", CY),
    "ic_more": _F("M5.4,7 a1.6,1.6 0 1,0 3.2,0 a1.6,1.6 0 1,0 -3.2,0 Z") + _F("M15.4,7 a1.6,1.6 0 1,0 3.2,0 a1.6,1.6 0 1,0 -3.2,0 Z") + _F("M5.4,17 a1.6,1.6 0 1,0 3.2,0 a1.6,1.6 0 1,0 -3.2,0 Z") + _F("M15.4,17 a1.6,1.6 0 1,0 3.2,0 a1.6,1.6 0 1,0 -3.2,0 Z"),
    "ic_refresh": _S("M19.5,12 a7.5,7.5 0 1,1 -2.2,-5.3") + _S("M19.5,4.5 V8.5 H15.5", CY),
    "ic_copy_log": _S("M9,9 H19 V19.5 H9 Z") + _S("M5,15 V4.5 H15", CY),
}


def patch_icon_set(work):
    """Replaces the line-icon set (More tiles, rows, tabs) with new sci-fi line icons of the same names."""
    existing = {}
    for f in glob.glob(str(work / "res" / "drawable*" / "*")) + glob.glob(str(work / "res" / "mipmap*" / "*")):
        existing.setdefault(os.path.basename(f).rsplit(".", 1)[0], []).append(f)
    done = []
    for name, body in ICON_SET.items():
        if name not in existing:
            continue
        for f in existing[name]:
            try:
                os.remove(f)
            except OSError:
                pass
        write(work / "res" / "drawable" / f"{name}.xml", _vec(body))
        done.append(name)
    # the old onion logo (Hosted Onion Services tile) becomes the servers icon too
    if "ic_menu_onion" in existing:
        for f in existing["ic_menu_onion"]:
            try:
                os.remove(f)
            except OSError:
                pass
        write(work / "res" / "drawable" / "ic_menu_onion.xml", _vec(ICON_SET["ic_onion"]))
        done.append("ic_menu_onion")
    print("icon set replaced:", done)
    missing = [n for n in ICON_SET if n not in existing]
    if missing:
        print("  (not in this app version, skipped):", missing)


def patch_connect_pill(work):
    """The big Connect button: dark glass with a gold edge instead of flat orange."""
    names = ["bg_rounded_orange"]
    n = 0
    for name in names:
        found = glob.glob(str(work / "res" / "drawable*" / (name + ".*")))
        for f in found:
            os.remove(f)
        if found:
            write(work / "res" / "drawable" / (name + ".xml"), f'''<?xml version="1.0" encoding="utf-8"?>
<layer-list xmlns:android="{ANS}">
  <item android:left="1dp" android:top="1dp" android:right="1dp" android:bottom="1dp"><shape android:shape="rectangle"><corners android:radius="40dp"/><stroke android:width="5dp" android:color="#33FFC400"/></shape></item>
  <item android:left="3dp" android:top="3dp" android:right="3dp" android:bottom="3dp"><shape android:shape="rectangle"><corners android:radius="40dp"/><gradient android:angle="270" android:startColor="#2A4B93" android:endColor="#0C1736"/><stroke android:width="2dp" android:color="{GOLD}"/></shape></item>
</layer-list>''')
            n += 1
    print("connect pill restyled:", n)


def patch_layout_text(work):
    """Literal texts written straight into layouts (not via strings) get the new name too."""
    n = 0
    for f in glob.glob(str(work / "res" / "layout*" / "*.xml")):
        s = open(f, encoding="utf-8").read()

        def fix(m):
            nonlocal n
            val = m.group(2)
            if val.startswith("@") or val.startswith("?"):
                return m.group(0)
            new = brand_text(val)
            if new != val:
                n += 1
                return m.group(1) + new + '"'
            return m.group(0)

        t2 = re.sub(r'(android:(?:text|hint|contentDescription)=")([^"]*)"', fix, s)
        if t2 != s:
            open(f, "w", encoding="utf-8").write(t2)
    print("layout literal texts rebranded:", n)


def patch_brand_drawables(work):
    """Any leftover drawable whose NAME is the old app, mascot or logo is blanked (transparent) and its ImageViews are hidden.
    (An earlier version drew the bat badge here, which is what showed up as a second floating icon under the mascot.)"""
    keep = {"orbiesleeping", "orbieon", "orbie_stuck", "ic_stat_tor", "ic_stat_tor_xfer", "ic_stat_notifyerr"}
    rxn = re.compile(r"(orbot|orbie|(^|_)tor(_|$))", re.I)
    blank = f'''<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="{ANS}" android:shape="rectangle"><solid android:color="#00000000"/></shape>'''
    done = set()
    for f in glob.glob(str(work / "res" / "drawable*" / "*")) + glob.glob(str(work / "res" / "mipmap*" / "*")):
        name = os.path.basename(f).rsplit(".", 1)[0]
        ext = f.rsplit(".", 1)[-1].lower()
        if name in keep or name.startswith("ic_launcher") or not rxn.search(name) or name.startswith("nerdyshield"):
            continue
        try:
            if ext in ("png", "webp"):
                Image.new("RGBA", Image.open(f).size, (0, 0, 0, 0)).save(f, "WEBP" if ext == "webp" else "PNG")
            elif ext == "xml":
                if "<vector" not in open(f, encoding="utf-8").read():
                    continue
                write(pathlib.Path(f), blank)
            else:
                continue
            done.add(name)
        except Exception as e:
            print("  skip", f, e)
    print("brand drawables blanked:", sorted(done))
    if done:
        hide_old_icon_views(work, done)


def dump_ui(work, dest):
    """Zips the decoded layouts/menus/colours/styles of the ORIGINAL app so the screens can be restyled against real ids."""
    pathlib.Path(dest).parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(dest, "w", zipfile.ZIP_DEFLATED) as z:
        for pat in ("layout*/*.xml", "menu*/*.xml", "navigation*/*.xml", "xml/*.xml", "values/colors.xml", "values/styles.xml", "values/themes.xml", "values/dimens.xml", "values/ids.xml"):
            for f in glob.glob(str(work / "res" / pat)):
                z.write(f, os.path.relpath(f, work))
        z.write(work / "AndroidManifest.xml", "AndroidManifest.xml")
        names = sorted(os.path.basename(x) for x in glob.glob(str(work / "res" / "drawable*" / "*")) + glob.glob(str(work / "res" / "mipmap*" / "*")))
        z.writestr("drawable-names.txt", "\n".join(names))
    print("ui dump:", dest)


def license_text(work):
    f = work / "assets" / "LICENSE"
    return f.read_text(encoding="utf-8", errors="replace") if f.exists() else "Open-source licence text was not found in the base app."


# ---------------------------------------------------------------- icons
def render_icon(size):
    """Launcher icon (legacy raster): deep-navy glow background, gold double-ring emblem with the bat, soft neon glow."""
    S = 3
    W = size * S
    glow_c = (30, 62, 130)
    base = Image.new("RGBA", (W, W), (5, 7, 13, 255))
    rad = Image.radial_gradient("L").resize((W, W), Image.BICUBIC)           # 0 centre -> 255 edge
    inv = rad.point(lambda v: max(0, 255 - int(v * 1.25)))
    base.paste(Image.new("RGBA", (W, W), glow_c + (255,)), (0, 0), inv)
    layer = Image.new("RGBA", (W, W), (0, 0, 0, 0))
    d = ImageDraw.Draw(layer)
    cx = cy = W / 2
    ew, eh = W * 0.74, W * 0.44
    gold, cyan = (255, 196, 0, 255), (56, 189, 248, 255)
    d.ellipse([cx - ew / 2, cy - eh / 2, cx + ew / 2, cy + eh / 2], outline=gold, width=max(2, int(W * 0.032)))
    iw, ih = ew * 0.915, eh * 0.885
    d.ellipse([cx - iw / 2, cy - ih / 2, cx + iw / 2, cy + ih / 2], outline=cyan, width=max(1, int(W * 0.008)))
    d.polygon(bat.polygon(W * 0.60 / 96, cx, cy), fill=gold)
    glow = layer.filter(ImageFilter.GaussianBlur(W * 0.018))
    im = Image.alpha_composite(base, glow)
    im = Image.alpha_composite(im, layer)
    mask = Image.new("L", (W, W), 0)
    ImageDraw.Draw(mask).rounded_rectangle([0, 0, W - 1, W - 1], radius=int(W * 0.22), fill=255)
    out = Image.new("RGBA", (W, W), (0, 0, 0, 0))
    out.paste(im, (0, 0), mask)
    return out.resize((size, size), Image.LANCZOS)


def write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text, encoding="utf-8")


def resolve_ref(ref):
    m = re.match(r"@(?:\w+:)?(mipmap|drawable)/(.+)", ref or "")
    return (m.group(1), m.group(2)) if m else None


def patch_icons(work, icon_refs):
    """The launcher icon is a NEW resource (nerdyshield_icon). Every OLD ic_launcher* resource becomes transparent, so the app's
    own screens (which draw the old icon under the mascot) show nothing, and their ImageViews are hidden later."""
    fg = f'''<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="{ANS}" android:width="108dp" android:height="108dp" android:viewportWidth="108" android:viewportHeight="108">
  <path android:fillColor="#00000000" android:strokeColor="#40FFC400" android:strokeWidth="4.2" android:pathData="M23.5,54 a30.5,18.2 0 1,0 61,0 a30.5,18.2 0 1,0 -61,0 Z"/>
  <path android:fillColor="#00000000" android:strokeColor="{GOLD}" android:strokeWidth="2.2" android:pathData="M23.5,54 a30.5,18.2 0 1,0 61,0 a30.5,18.2 0 1,0 -61,0 Z"/>
  <path android:fillColor="#00000000" android:strokeColor="#38BDF8" android:strokeWidth="0.6" android:pathData="M27,54 a27,15.8 0 1,0 54,0 a27,15.8 0 1,0 -54,0 Z"/>
  <path android:fillColor="{GOLD}" android:pathData="{bat.path_d(0.5, 54, 54)}"/>
</vector>'''
    bgx = f'''<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="{ANS}" android:shape="rectangle"><gradient android:type="radial" android:centerX="0.5" android:centerY="0.46" android:gradientRadius="78%" android:startColor="#1E3F85" android:endColor="#05070D"/></shape>'''
    write(work / "res/drawable/nerdyshield_fg.xml", fg)
    write(work / "res/drawable/nerdyshield_bg.xml", bgx)
    write(work / "res/mipmap-anydpi-v26/nerdyshield_icon.xml", f'''<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="{ANS}"><background android:drawable="@drawable/nerdyshield_bg"/><foreground android:drawable="@drawable/nerdyshield_fg"/></adaptive-icon>''')
    for d, px in (("mdpi", 48), ("hdpi", 72), ("xhdpi", 96), ("xxhdpi", 144), ("xxxhdpi", 192)):
        (work / f"res/mipmap-{d}").mkdir(parents=True, exist_ok=True)
        render_icon(px).save(work / f"res/mipmap-{d}/nerdyshield_icon.png", "PNG")
    blank_xml = f'''<?xml version="1.0" encoding="utf-8"?>
<shape xmlns:android="{ANS}" android:shape="rectangle"><solid android:color="#00000000"/></shape>'''
    blank_adaptive = f'''<?xml version="1.0" encoding="utf-8"?>
<adaptive-icon xmlns:android="{ANS}"><background android:drawable="@android:color/transparent"/><foreground android:drawable="@android:color/transparent"/></adaptive-icon>'''
    names = set()
    for ref in icon_refs:
        rr = resolve_ref(ref)
        if rr:
            names.add(rr[1])
    for f in glob.glob(str(work / "res" / "mipmap*" / "ic_launcher*")) + glob.glob(str(work / "res" / "drawable*" / "ic_launcher*")):
        names.add(os.path.basename(f).rsplit(".", 1)[0])
    names = {n for n in names if not n.startswith("nerdyshield")}
    n_files = 0
    for f in glob.glob(str(work / "res" / "mipmap*" / "*")) + glob.glob(str(work / "res" / "drawable*" / "*")):
        base = os.path.basename(f).rsplit(".", 1)[0]
        ext = f.rsplit(".", 1)[-1].lower()
        if base not in names:
            continue
        try:
            if ext in ("png", "webp"):
                size = Image.open(f).size
                Image.new("RGBA", size, (0, 0, 0, 0)).save(f, "WEBP" if ext == "webp" else "PNG")
            elif ext == "xml":
                txt = open(f, encoding="utf-8").read()
                write(pathlib.Path(f), blank_adaptive if "<adaptive-icon" in txt else blank_xml)
            else:
                continue
            n_files += 1
        except Exception as e:
            print("  skip", f, e)
    print(f"icons: new launcher icon written; {n_files} old icon files blanked; names: {sorted(names)}")
    return names


def hide_old_icon_views(work, names):
    """Hides every ImageView in the app's own layouts that draws one of the old launcher icons (the 'second icon' under the mascot)."""
    n = 0
    for f in glob.glob(str(work / "res" / "layout*" / "*.xml")):
        try:
            tree = etree.parse(f)
        except Exception:
            continue
        ch = False
        for el in tree.iter():
            if not isinstance(el.tag, str):
                continue
            refs = [el.get(A + "src") or "", el.get("{http://schemas.android.com/apk/res-auto}srcCompat") or "", el.get(A + "background") or ""]
            if any(re.search(r"@(?:\w+:)?(?:mipmap|drawable)/(%s)$" % "|".join(map(re.escape, names)), r) for r in refs if r) and names:
                el.set(A + "visibility", "gone")
                ch = True
                n += 1
        if ch:
            tree.write(f, xml_declaration=True, encoding="utf-8")
    print("old icon views hidden:", n)


# ---------------------------------------------------------------- manifest
def patch_manifest(work, orbot_main_hint):
    mf = work / "AndroidManifest.xml"
    tree = etree.parse(str(mf))
    root = tree.getroot()
    pkg = root.get("package")
    app = root.find("application")
    icons = [app.get(A + "icon"), app.get(A + "roundIcon")]
    launcher = None
    for el in list(app):
        if el.tag != "activity":
            continue
        for f in el.findall("intent-filter"):
            for c in f.findall("category"):
                if c.get(A + "name") == "android.intent.category.LAUNCHER":
                    f.remove(c)
                    launcher = el.get(A + "name")
    if launcher and launcher.startswith("."):
        launcher = pkg + launcher
    if launcher and "." not in launcher:
        launcher = pkg + "." + launcher
    print("original launcher activity:", launcher)

    def act(name, exported, extra=None):
        e = etree.SubElement(app, "activity")
        e.set(A + "name", f"{NS_PKG}.{name}")
        e.set(A + "exported", "true" if exported else "false")
        e.set(A + "theme", "@android:style/Theme.Material.Light.NoActionBar")
        e.set(A + "configChanges", "orientation|screenSize|keyboardHidden|uiMode|screenLayout|smallestScreenSize")
        for k, v in (extra or {}).items():
            e.set(A + k, v)
        return e

    extra = {"label": "@string/app_name", "noHistory": "true", "excludeFromRecents": "true"}
    for el in app.findall("activity"):
        if el.get(A + "name") in (launcher, (launcher or "").replace(pkg + ".", ".")) and el.get(A + "taskAffinity") is not None:
            extra["taskAffinity"] = el.get(A + "taskAffinity")
    sp = act("SplashActivity", True, extra)
    f = etree.SubElement(sp, "intent-filter")
    etree.SubElement(f, "action").set(A + "name", "android.intent.action.MAIN")
    etree.SubElement(f, "category").set(A + "name", "android.intent.category.LAUNCHER")
    md = etree.SubElement(sp, "meta-data")
    md.set(A + "name", "android.app.shortcuts")
    md.set(A + "resource", "@xml/nerdyshield_shortcuts")
    act("HubActivity", False, {"label": "@string/app_name", "launchMode": "singleTop"})
    pv = etree.SubElement(app, "provider")
    pv.set(A + "name", f"{NS_PKG}.NsInit")
    pv.set(A + "authorities", f"{pkg}.nsinit")
    pv.set(A + "exported", "false")
    app.set(A + "icon", "@mipmap/nerdyshield_icon")
    app.set(A + "roundIcon", "@mipmap/nerdyshield_icon")
    tree.write(str(mf), xml_declaration=True, encoding="utf-8")
    return pkg, launcher or orbot_main_hint, icons


def write_shortcuts(work, pkg, main_cls):
    def one(i, route, label):
        return (f'  <shortcut android:shortcutId="ns_{route}" android:enabled="true" android:shortcutShortLabel="@string/{label}" android:shortcutLongLabel="@string/{label}">\n'
                f'    <intent android:action="android.intent.action.VIEW" android:targetPackage="{pkg}" android:targetClass="{NS_PKG}.HubActivity">\n'
                f'      <extra android:name="route" android:value="{route}"/>\n    </intent>\n  </shortcut>\n')
    xml = (f'<?xml version="1.0" encoding="utf-8"?>\n<shortcuts xmlns:android="{ANS}">\n'
           + one(0, "about", "ns_sc_about") + one(1, "safety", "ns_sc_safety") + one(2, "build", "ns_sc_build") + '</shortcuts>')
    write(work / "res/xml/nerdyshield_shortcuts.xml", xml)
    f = work / "res/values/strings.xml"
    t = f.read_text(encoding="utf-8")
    add = ('    <string name="ns_sc_about">About me</string>\n    <string name="ns_sc_safety">Stay safe</string>\n'
           '    <string name="ns_sc_build">Build info</string>\n')
    f.write_text(t.replace("</resources>", add + "</resources>"), encoding="utf-8")



# ---------------------------------------------------------------- theme (Orbot's own named colours)
GOLD = "#FFC400"
PALETTES = {  # Orbot colour name -> NerdyShield value. Orbot's UI is dark with white text, so backgrounds stay mid/deep tones.
    "blue": {"bg": "#0F2F66", "card": "#1A4488", "btn_off": "#33507F", "deep": "#0D2A5C", "g1": "#33FFC400", "g2": "#3338BDF8", "g3": "#401A4FA0"},
    "teal": {"bg": "#0B4A55", "card": "#0F6171", "btn_off": "#2C6470", "deep": "#083A44", "g1": "#33FFC400", "g2": "#3322D3EE", "g3": "#400F6171"},
    "ink":  {"bg": "#151A26", "card": "#222A3C", "btn_off": "#363E52", "deep": "#0E121B", "g1": "#33FFC400", "g2": "#33FFFFFF", "g3": "#40222A3C"},
}


def patch_colors(work, palette):
    P = PALETTES.get(palette, PALETTES["blue"])
    m = {
        "new_background": P["bg"], "dark_purple": P["deep"],
        "bg_gradient_start": P["g1"], "bg_gradient_end": P["g2"], "bg_gradient_center": P["g3"],
        "orbot_btn_enabled_purple": "#D97706", "orbot_btn_disable_grey": P["btn_off"],
        "progress_bar_purple": GOLD, "text_purple": "#FFD54F", "menu_header": "#FFD54F",
        "panel_widget_background": P["card"], "panel_card_image": "#FFE08A",
        "ic_launcher_background": AMBER, "ic_launcher_foreground_alt1_background": AMBER,
        "ic_launcher_foreground_alt2_background": AMBER, "ic_launcher_foreground_alt3_background": AMBER,
        "ic_launcher_foreground_alt4_background": AMBER,
    }
    hit = set()
    for f in glob.glob(str(work / "res" / "values*" / "*.xml")):
        t = open(f, encoding="utf-8").read()
        o = t
        for name, val in m.items():
            t, n = re.subn(r'(<color name="%s"[^>]*>)[^<]*(</color>)' % re.escape(name), r"\g<1>%s\g<2>" % val, t)
            if n:
                hit.add(name)
        if t != o:
            open(f, "w", encoding="utf-8").write(t)
    print(f"palette '{palette}': recoloured {len(hit)}/{len(m)} named colours; missing: {sorted(set(m) - hit)}")


def vec_attr(path, attr, default):
    try:
        mm = re.search(r'android:%s="([^"]+)"' % attr, open(path, encoding="utf-8").read())
        return mm.group(1) if mm else default
    except Exception:
        return default


def patch_mascot(work):
    """Replace Orbot's mascot (Orbie) in all three states with the NerdyShield bat logo."""
    states = {
        "orbiesleeping": dict(oval="#9FB0C6", ring="#44506A", bat="#44506A", glow=None),
        "orbieon":       dict(oval=YELLOW, ring=INK, bat=INK, glow="#22C55E"),
        "orbie_stuck":   dict(oval=YELLOW, ring=INK, bat=INK, glow="#EF4444"),
    }
    oval = "M6,62.08 a60,37 0 1,0 120,0 a60,37 0 1,0 -120,0 Z"
    halo = "M2,62.08 a64,41 0 1,0 128,0 a64,41 0 1,0 -128,0 Z"
    for name, c in states.items():
        found = glob.glob(str(work / "res" / "drawable*" / f"{name}.xml"))
        w = vec_attr(found[0], "width", "150dp") if found else "150dp"
        h = vec_attr(found[0], "height", "141dp") if found else "141dp"
        glow = (f'  <path android:strokeColor="{c["glow"]}" android:strokeWidth="3.5" android:fillColor="#00000000" android:pathData="{halo}"/>\n' if c["glow"] else "")
        xml = (f'<?xml version="1.0" encoding="utf-8"?>\n<vector xmlns:android="{ANS}" android:width="{w}" android:height="{h}" '
               f'android:viewportWidth="132" android:viewportHeight="124.16">\n{glow}'
               f'  <path android:fillColor="{c["oval"]}" android:strokeColor="{c["ring"]}" android:strokeWidth="3" android:pathData="{oval}"/>\n'
               f'  <path android:fillColor="{c["bat"]}" android:pathData="{bat.path_d(1.1, 66, 62.08)}"/>\n</vector>')
        for f in found or [str(work / "res/drawable" / f"{name}.xml")]:
            write(pathlib.Path(f), xml)
        print(f"mascot {name}: replaced {len(found) or 'new'}")


def patch_notification_icons(work):
    n = 0
    for name in ("ic_stat_tor", "ic_stat_tor_xfer", "ic_stat_notifyerr"):
        for f in glob.glob(str(work / "res" / "drawable*" / f"{name}.png")):
            try:
                size = Image.open(f).size[0]
                W = size * 4
                im = Image.new("RGBA", (W, W), (0, 0, 0, 0))
                ImageDraw.Draw(im).polygon(bat.polygon(W * 0.86 / 96, W / 2, W / 2), fill=(255, 255, 255, 255))
                im.resize((size, size), Image.LANCZOS).save(f, "PNG")
                n += 1
            except Exception as e:
                print("  skip", f, e)
    print("notification icons replaced:", n)


def esc(t):
    return (t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace('"', "&quot;")
             .replace("'", "\u2019").replace("\n", "&#10;"))


LICENSE_TXT = [""]
ABOUT_ME = [
    ("ABOUT ME \u00b7 NERDYSHIELD", "Built by Raghu, @NerdyIntruder.\nI am an active retail trader: equity and F&O on NSE and BSE, plus BTC and ETH on Delta Exchange. I write about trading psychology, discipline and performance.\nI never follow random advice. Every idea, indicator and tool gets tested from every angle first. That is how this app was made too."),
    ("MY STORY", "I started trading in 2018 and lost money while I learned how markets really behave. From 2020 to 2023 I worked freelance and regular jobs: video editing, After Effects, Blender, and an entry-level role at Fyers, where I listened to traders and saw the same emotional mistakes again and again.\nAfter a hard personal stretch I quit alcohol, studied habits, neuroscience and trading, learned to think in systems and built my own tools. I have been sober for almost a year now."),
    ("MY BOOKS", "The False Green\nWho\u2019s Trading Your Account? The Second Trader\nThe Eight Power and Trading Paradoxes\nThe Inner Citadel Trade\nThe Blind Candle"),
    ("HOW THIS APP IS BUILT", "NerdyShield is built on open-source software (BSD 3-Clause). The full licence notice is at the bottom of this page and in the Build tab of the hub."),
    ("FIND ME", "https://www.instagram.com/nerdyintruder/\nLong-press the app icon for shortcuts: About me, Stay safe, Build info."),
]


def patch_about(work):
    f = work / "res/layout/layout_about.xml"
    if not f.exists():
        print("WARNING: layout_about.xml not found; About page not added")
        return
    t = f.read_text(encoding="utf-8")
    i = t.rfind("</LinearLayout>")
    if i < 0:
        print("WARNING: no LinearLayout end in layout_about.xml")
        return
    out = []
    for head, body in ABOUT_ME:
        out.append(f'<TextView android:layout_width="match_parent" android:layout_height="wrap_content" android:paddingTop="18dp" '
                   f'android:text="{esc(head)}" android:textStyle="bold" android:textColor="@color/panel_card_image"/>')
        out.append(f'<TextView android:layout_width="match_parent" android:layout_height="wrap_content" android:paddingTop="4dp" '
                   f'android:text="{esc(body)}" android:textColor="@android:color/white" android:textColorLink="#FFD54F" android:autoLink="web"/>')
    out.append(f'<TextView android:layout_width="match_parent" android:layout_height="wrap_content" android:paddingTop="18dp" android:text="OPEN-SOURCE LICENCES" android:textStyle="bold" android:textColor="@color/panel_card_image"/>')
    out.append(f'<TextView android:layout_width="match_parent" android:layout_height="wrap_content" android:paddingTop="4dp" android:textSize="11sp" android:alpha="0.8" android:text="{esc(LICENSE_TXT[0])}" android:textColor="@android:color/white"/>')
    out.append('<View android:layout_width="match_parent" android:layout_height="24dp"/>')
    f.write_text(t[:i] + "\n".join(out) + "\n" + t[i:], encoding="utf-8")
    print("About page appended to layout_about.xml")


# ---------------------------------------------------------------- assets + java
def mix(h1, h2, k):
    a = [int(h1[i:i + 2], 16) for i in (1, 3, 5)]
    b = [int(h2[i:i + 2], 16) for i in (1, 3, 5)]
    return "#%02X%02X%02X" % tuple(int(a[i] + (b[i] - a[i]) * k) for i in range(3))


def copy_assets(work, palette="blue"):
    d = work / "assets" / "shield"
    d.mkdir(parents=True, exist_ok=True)
    bd = bat.path_d(1.0, 0, 0, 2)
    lic = license_text(work).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    for f in (ROOT / "overlay/assets/shield").iterdir():
        if f.suffix == ".html":
            (d / f.name).write_text(f.read_text(encoding="utf-8").replace("__BAT_D__", bd).replace("__LICENSE_TEXT__", lic).replace("__END_TOP__", mix(PALETTES.get(palette, PALETTES["blue"])["bg"], "#6B7A8C", 0.35)).replace("__END_BOT__", PALETTES.get(palette, PALETTES["blue"])["card"]), encoding="utf-8")
        elif f.suffix in (".ogg", ".mp3", ".wav"):
            shutil.copy(f, d / f.name)
    for ext in ("jpg", "jpeg", "png", "webp"):
        p = ROOT / f"raghu.{ext}"
        if p.exists():
            shutil.copy(p, d / p.name)
            print("added photo", p.name)


def find_sdk():
    sdk = os.environ.get("ANDROID_HOME") or os.environ.get("ANDROID_SDK_ROOT") or "/usr/local/lib/android/sdk"
    ver = lambda p: [int(x) if x.isdigit() else 0 for x in re.split(r"[.\-]", os.path.basename(p))]
    plats = sorted(glob.glob(f"{sdk}/platforms/android-*"), key=lambda p: int(re.findall(r"\d+", os.path.basename(p))[0]))
    bts = sorted([b for b in glob.glob(f"{sdk}/build-tools/*") if os.path.exists(b + "/d8")], key=ver)
    if not plats or not bts:
        sys.exit(f"Android SDK not found in {sdk} (need platforms + build-tools with d8)")
    android_jar = [p for p in plats if p.endswith("android-34")] or plats
    return pathlib.Path(android_jar[-1]) / "android.jar", pathlib.Path(bts[-1])


def compile_java(tmp, main_cls, min_api):
    android_jar, bt = find_sdk()
    src = tmp / "src"
    shutil.copytree(ROOT / "overlay/java", src)
    br = next(src.rglob("ShieldBridge.java"))
    t = br.read_text(encoding="utf-8")
    t = re.sub(r'SHIELD_MAIN = "[^"]*"', f'SHIELD_MAIN = "{main_cls}"', t)
    br.write_text(t, encoding="utf-8")
    cls = tmp / "classes"
    cls.mkdir()
    files = [str(p) for p in src.rglob("*.java")]
    sh(["javac", "--release", "8", "-Xlint:-options", "-cp", android_jar, "-d", cls] + files)
    out = tmp / "dexout"
    out.mkdir()
    classes = [str(p) for p in cls.rglob("*.class")]
    sh([bt / "d8", "--release", "--min-api", str(min_api), "--lib", android_jar, "--output", out] + classes)
    return out / "classes.dex", bt


def main():
    apk, apktool, out_apk = (pathlib.Path(x).resolve() for x in sys.argv[1:4])
    tmp = pathlib.Path("build_shield").resolve()
    shutil.rmtree(tmp, ignore_errors=True)
    tmp.mkdir()
    work = tmp / "work"
    sh(["java", "-jar", apktool, "d", "-s", "-f", "--keep-broken-res", "-o", work, apk])
    dump_ui(work, out_apk.parent / "ui-dump.zip")
    yml = (work / "apktool.yml").read_text()
    m = re.search(r"minSdkVersion:\s*'?(\d+)", yml)
    min_api = max(21, int(m.group(1))) if m else 24

    pkg, main_cls, icons = patch_manifest(work, "org.torproject.android.OrbotActivity")
    LICENSE_TXT[0] = license_text(work)
    patch_strings(work)
    patch_manifest_labels(work)
    patch_donate(work)
    old_names = patch_icons(work, icons)
    hide_old_icon_views(work, old_names)
    patch_colors(work, os.environ.get("NS_PALETTE", "blue"))
    patch_mascot(work)
    patch_notification_icons(work)
    patch_brand_drawables(work)
    patch_nav(work)
    patch_icon_set(work)
    patch_connect_pill(work)
    patch_layout_text(work)
    patch_about(work)
    write_shortcuts(work, pkg, main_cls)
    copy_assets(work, os.environ.get("NS_PALETTE", "blue"))

    unsigned = tmp / "unsigned.apk"
    sh(["java", "-jar", apktool, "b", "-o", unsigned, work])
    dex, bt = compile_java(tmp, main_cls, min_api)
    with zipfile.ZipFile(unsigned) as z:
        n = len([x for x in z.namelist() if re.fullmatch(r"classes\d*\.dex", x)])
    newname = f"classes{n + 1}.dex"
    with zipfile.ZipFile(unsigned, "a") as z:
        z.write(dex, newname, compress_type=zipfile.ZIP_DEFLATED)
    print(f"added {newname} (had {n} dex files)")

    aligned = tmp / "aligned.apk"
    sh([bt / "zipalign", "-f", "-p", "4", unsigned, aligned])
    out_apk.parent.mkdir(parents=True, exist_ok=True)
    sh([bt / "apksigner", "sign", "--ks", KS, "--ks-pass", f"pass:{KS_PASS}", "--ks-key-alias", KS_ALIAS,
        "--key-pass", f"pass:{KS_PASS}", "--out", out_apk, aligned])
    sh([bt / "apksigner", "verify", "--print-certs", out_apk])
    print("DONE ->", out_apk, f"({out_apk.stat().st_size/1e6:.1f} MB)")


if __name__ == "__main__":
    main()
