package com.nerdyintruder.nerdyshield;

import android.app.Activity;
import android.app.Application;
import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.FrameLayout;

/** Starts with the app (a provider is created before any activity) and adds the live-network panel to the main screen. */
public class NsInit extends ContentProvider {
    @Override public boolean onCreate() {
        try { if (getContext() != null) CrashLog.install(getContext().getApplicationContext() != null ? getContext().getApplicationContext() : getContext()); } catch (Throwable ignored) { }
        try {
            Context c = getContext();
            Application app = c == null ? null : (Application) c.getApplicationContext();
            if (app != null) app.registerActivityLifecycleCallbacks(new Host());
        } catch (Throwable ignored) { }
        return true;
    }

    static final class Host implements Application.ActivityLifecycleCallbacks {
        private static boolean isMain(Activity a) { return a.getClass().getName().equals(ShieldBridge.SHIELD_MAIN); }

        @Override public void onActivityResumed(Activity a) {
            TextSweep.attach(a);
            if (!isMain(a)) return;
            try {
                StatsOverlay o = (StatsOverlay) a.findViewById(StatsOverlay.ID);
                if (o == null) {
                    o = new StatsOverlay(a);
                    o.setId(StatsOverlay.ID);
                    float d = a.getResources().getDisplayMetrics().density;
                    FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(FrameLayout.LayoutParams.MATCH_PARENT, (int) (StatsOverlay.DESIGN_H * d), Gravity.BOTTOM);
                    lp.leftMargin = lp.rightMargin = (int) (18 * d);
                    lp.bottomMargin = (int) (112 * d);
                    a.addContentView(o, lp);
                }
                o.resume();
            } catch (Throwable ignored) { }
        }

        @Override public void onActivityPaused(Activity a) {
            if (!isMain(a)) return;
            try {
                StatsOverlay o = (StatsOverlay) a.findViewById(StatsOverlay.ID);
                if (o != null) o.pause();
            } catch (Throwable ignored) { }
        }

        @Override public void onActivityCreated(Activity a, Bundle b) { }
        @Override public void onActivityStarted(Activity a) { }
        @Override public void onActivityStopped(Activity a) { }
        @Override public void onActivitySaveInstanceState(Activity a, Bundle b) { }
        @Override public void onActivityDestroyed(Activity a) { }
    }

    @Override public Cursor query(Uri u, String[] p, String s, String[] a, String o) { return null; }
    @Override public String getType(Uri u) { return null; }
    @Override public Uri insert(Uri u, ContentValues v) { return null; }
    @Override public int delete(Uri u, String s, String[] a) { return 0; }
    @Override public int update(Uri u, ContentValues v, String s, String[] a) { return 0; }
}
