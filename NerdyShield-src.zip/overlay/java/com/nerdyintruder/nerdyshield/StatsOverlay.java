package com.nerdyintruder.nerdyshield;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.TrafficStats;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.content.res.Configuration;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.RadioButton;

/** "NET-SCOPE": a sci-fi glass console with two live gauges, a scrolling 60 s scope, a radar sweep and a stats grid.
 *  Tilts in 3D with the phone and shows only on the Connect screen. */
public class StatsOverlay extends View implements SensorEventListener {
    static final int ID = 0x4e530001;
    static final int DESIGN_H = 340;                 // dp the layout below is designed for
    private static final int N = 60;
    private static final int GOLD = 0xFFFFC400, CYAN = 0xFF38BDF8, DIM = 0xFF8FA3C8, WHITE = 0xFFEAF2FF, GREEN = 0xFF3DDC84;

    private final float d;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG), t = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path line = new Path(), area = new Path();
    private final RectF r = new RectF(), arc = new RectF();
    private final double[] dl = new double[N], ul = new double[N];
    private final Handler h = new Handler(Looper.getMainLooper());
    private final int uid = android.os.Process.myUid();
    private final long born = SystemClock.elapsedRealtime();
    private long lastT, lastRx, lastTx, totRx, totTx, lastPk, pkRate;
    private double tgtDl, tgtUl, shDl, shUl, peakDl, peakUl, sumDl, sumUl;
    private int samples;
    private boolean running, shown = true, vpnOn;
    private String link = "--";
    private long lastLinkCheck;
    private float tiltX, tiltY;
    private SensorManager sm;

    public StatsOverlay(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        setCameraDistance(d * 9000f);
        setAlpha(0f);
        setClickable(false);
        setFocusable(false);
    }

    void resume() {
        if (running) return;
        running = true;
        lastT = 0;
        try {
            sm = (SensorManager) getContext().getSystemService(Context.SENSOR_SERVICE);
            Sensor s = sm == null ? null : sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            if (s != null) sm.registerListener(this, s, SensorManager.SENSOR_DELAY_UI);
        } catch (Throwable ignored) { }
        h.post(tick);
        h.post(frame);
    }

    void pause() {
        running = false;
        h.removeCallbacks(tick);
        h.removeCallbacks(frame);
        try { if (sm != null) sm.unregisterListener(this); } catch (Throwable ignored) { }
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!running) return;
            sample();
            boolean want = fitToConnectScreen();
            if (want != shown) {
                shown = want;
                animate().alpha(want ? 1f : 0f).setDuration(300).start();
            } else if (getAlpha() == 0f && want) {
                animate().alpha(1f).setDuration(450).start();
            }
            h.postDelayed(this, 1000);
        }
    };

    private final Runnable frame = new Runnable() {
        @Override public void run() {
            if (!running) return;
            shDl += (tgtDl - shDl) * 0.22;
            shUl += (tgtUl - shUl) * 0.22;
            if (getAlpha() > 0.02f) invalidate();
            h.postDelayed(this, 33);
        }
    };

    /** The Connect pill is the only plain switch on the Connect screen (the app list uses check boxes). */
    private static View findSwitch(View v) {
        if (v == null || v.getVisibility() != VISIBLE) return null;
        if (v instanceof CompoundButton && !(v instanceof CheckBox) && !(v instanceof RadioButton)) return v.isShown() ? v : null;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) { View f = findSwitch(g.getChildAt(i)); if (f != null) return f; }
        }
        return null;
    }

    /** Shows the panel only on the Connect screen, in portrait, and sizes it to the free space under the Connect pill. */
    private boolean fitToConnectScreen() {
        try {
            if (getResources().getConfiguration().orientation != Configuration.ORIENTATION_PORTRAIT) return false;
            View sw = findSwitch(getRootView());
            if (sw == null || !(getParent() instanceof View) || !(getLayoutParams() instanceof ViewGroup.MarginLayoutParams)) return false;
            int[] a = new int[2], b = new int[2];
            sw.getLocationInWindow(a);
            View par = (View) getParent();
            par.getLocationInWindow(b);
            ViewGroup.MarginLayoutParams lp = (ViewGroup.MarginLayoutParams) getLayoutParams();
            int avail = (b[1] + par.getHeight()) - lp.bottomMargin - (a[1] + sw.getHeight() + (int) (14 * d));
            int target = Math.min((int) (DESIGN_H * d), avail);
            if (target < (int) (230 * d)) return false;
            if (Math.abs(lp.height - target) > (int) (3 * d)) { lp.height = target; setLayoutParams(lp); }
            return true;
        } catch (Throwable t) {
            return false;
        }
    }

    private void checkLink() {
        long now = SystemClock.elapsedRealtime();
        if (now - lastLinkCheck < 3000) return;
        lastLinkCheck = now;
        try {
            ConnectivityManager cm = (ConnectivityManager) getContext().getSystemService(Context.CONNECTIVITY_SERVICE);
            boolean vpn = false;
            String l = "--";
            for (Network n : cm.getAllNetworks()) {
                NetworkCapabilities nc = cm.getNetworkCapabilities(n);
                if (nc == null) continue;
                if (nc.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) vpn = true;
                else if (nc.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) {
                    if (nc.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) l = "WI-FI";
                    else if (nc.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)) l = "MOBILE";
                    else if (nc.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) l = "ETHERNET";
                }
            }
            vpnOn = vpn;
            link = l;
        } catch (Throwable ignored) { }
    }

    private void sample() {
        long now = SystemClock.elapsedRealtime();
        long rx = TrafficStats.getUidRxBytes(uid), tx = TrafficStats.getUidTxBytes(uid);
        long pk = TrafficStats.getUidRxPackets(uid) + TrafficStats.getUidTxPackets(uid);
        if (rx == TrafficStats.UNSUPPORTED || tx == TrafficStats.UNSUPPORTED) { rx = TrafficStats.getTotalRxBytes(); tx = TrafficStats.getTotalTxBytes(); pk = 0; }
        if (lastT != 0 && rx >= lastRx && tx >= lastTx) {
            double dt = (now - lastT) / 1000.0;
            if (dt > 0.2) {
                double a = (rx - lastRx) / dt, b = (tx - lastTx) / dt;
                System.arraycopy(dl, 1, dl, 0, N - 1);
                System.arraycopy(ul, 1, ul, 0, N - 1);
                dl[N - 1] = a;
                ul[N - 1] = b;
                tgtDl = a;
                tgtUl = b;
                totRx += rx - lastRx;
                totTx += tx - lastTx;
                if (a > peakDl) peakDl = a;
                if (b > peakUl) peakUl = b;
                sumDl += a; sumUl += b; samples++;
                pkRate = pk >= lastPk ? (long) ((pk - lastPk) / dt) : 0;
            }
        }
        lastT = now; lastRx = rx; lastTx = tx; lastPk = pk;
        checkLink();
    }

    @Override public void onSensorChanged(SensorEvent e) {
        float x = e.values[0], y = e.values[1];
        float ty = Math.max(-4.5f, Math.min(4.5f, -x * 0.8f));
        float tx = Math.max(-3.5f, Math.min(3.5f, (y - 7.5f) * 0.7f));
        tiltY += (ty - tiltY) * 0.08f;
        tiltX += (tx - tiltX) * 0.08f;
        setRotationY(tiltY);
        setRotationX(tiltX);
    }

    @Override public void onAccuracyChanged(Sensor s, int a) { }

    @Override protected void onDetachedFromWindow() { pause(); super.onDetachedFromWindow(); }

    // ------------------------------------------------------------------ formatting
    private static String[] speed(double b) {
        if (b < 1024) return new String[]{String.format("%.0f", b), "B/s"};
        if (b < 1048576) return new String[]{String.format("%.1f", b / 1024), "KB/s"};
        return new String[]{String.format("%.2f", b / 1048576), "MB/s"};
    }

    private static String size(long b) {
        if (b < 1024) return b + " B";
        if (b < 1048576) return String.format("%.1f KB", b / 1024.0);
        if (b < 1073741824L) return String.format("%.1f MB", b / 1048576.0);
        return String.format("%.2f GB", b / 1073741824.0);
    }

    private static String clock(long ms) {
        long s = ms / 1000, hh = s / 3600, mm = (s % 3600) / 60, ss = s % 60;
        return hh > 0 ? String.format("%d:%02d:%02d", hh, mm, ss) : String.format("%02d:%02d", mm, ss);
    }

    private static String rate(double b) { String[] s = speed(b); return s[0] + " " + s[1]; }

    // ------------------------------------------------------------------ drawing
    @Override protected void onDraw(Canvas c) {
        float sc = Math.min(1f, getHeight() / (DESIGN_H * d));
        float w = getWidth() / sc, hh = getHeight() / sc;
        float tms = (SystemClock.elapsedRealtime() - born) / 1000f;
        c.save();
        c.scale(sc, sc);

        // ---- glass body, double border, scan line
        r.set(2 * d, 2 * d, w - 2 * d, hh - 2 * d);
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, 0, 0, hh, 0x3A0A1A3A, 0x66050A1C, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, 22 * d, 22 * d, p);
        p.setShader(new LinearGradient(0, 0, w, hh, 0x2838BDF8, 0x00000000, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, 22 * d, 22 * d, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.2f * d);
        p.setColor(0x6638BDF8);
        c.drawRoundRect(r, 22 * d, 22 * d, p);
        r.inset(5 * d, 5 * d);
        p.setStrokeWidth(0.8f * d);
        p.setColor(0x26FFFFFF);
        c.drawRoundRect(r, 17 * d, 17 * d, p);
        r.inset(-5 * d, -5 * d);

        c.save();
        c.translate(-tiltY * 1.1f * d, tiltX * 0.8f * d);          // inner layer moves against the tilt = depth

        // ---- header
        t.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        t.setLetterSpacing(0.28f);
        t.setTextSize(10.5f * d);
        t.setTextAlign(Paint.Align.LEFT);
        t.setColor(CYAN);
        c.drawText("NET-SCOPE", 18 * d, 30 * d, t);
        t.setColor(0xFF5D6F92);
        c.drawText("//", 18 * d + t.measureText("NET-SCOPE") + 8 * d, 30 * d, t);
        t.setColor(DIM);
        c.drawText("NERDYSHIELD", 18 * d + t.measureText("NET-SCOPE // ") + 12 * d, 30 * d, t);
        boolean active = vpnOn;
        float pulse = 0.55f + 0.45f * (float) Math.sin(tms * 4f);
        t.setTextAlign(Paint.Align.RIGHT);
        t.setColor(active ? GREEN : 0xFF7A88A8);
        c.drawText(active ? "SHIELD ACTIVE" : "STANDBY", w - 34 * d, 30 * d, t);
        p.setStyle(Paint.Style.FILL);
        p.setColor(active ? ((int) (pulse * 255) << 24) | 0x3DDC84 : 0xFF5D6F92);
        c.drawCircle(w - 23 * d, 26.5f * d, 4f * d, p);
        p.setColor(active ? 0x333DDC84 : 0x00000000);
        c.drawCircle(w - 23 * d, 26.5f * d, (6f + 3f * pulse) * d, p);

        // ---- gauges
        double mxD = Math.max(512 * 1024, max(dl)), mxU = Math.max(256 * 1024, max(ul));
        gauge(c, w * 0.26f, 118 * d, 54 * d, "DOWNLINK", "\u25BC", shDl, mxD, GOLD, tms);
        gauge(c, w * 0.74f, 118 * d, 54 * d, "UPLINK", "\u25B2", shUl, mxU, CYAN, tms + 1.3f);

        // ---- scope (graph)
        float gx = 18 * d, gw = w - 36 * d, gt = 196 * d, gb = 256 * d;
        arc.set(gx, gt - 6 * d, gx + gw, gb + 6 * d);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0x33000000);
        c.drawRoundRect(arc, 10 * d, 10 * d, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1f);
        p.setColor(0x1FFFFFFF);
        for (int i = 1; i < 3; i++) { float y = gt + (gb - gt) * i / 3f; c.drawLine(gx, y, gx + gw, y, p); }
        float step = gw / 6f, off = (tms * 0.0f) % step;
        float phase = ((SystemClock.elapsedRealtime() % 1000) / 1000f) * (gw / (N - 1f));
        for (int i = 0; i <= 6; i++) { float x = gx + i * step - phase; if (x >= gx && x <= gx + gw) c.drawLine(x, gt - 4 * d, x, gb + 4 * d, p); }
        double gmax = Math.max(Math.max(mxD, mxU), 10 * 1024);
        graph(c, dl, gmax, gx, gw, gt, gb, GOLD, true);
        graph(c, ul, gmax, gx, gw, gt, gb, CYAN, false);
        t.setTypeface(Typeface.create("monospace", Typeface.NORMAL));
        t.setLetterSpacing(0.05f);
        t.setTextSize(8.5f * d);
        t.setColor(0xFF6E7FA3);
        t.setTextAlign(Paint.Align.LEFT);
        c.drawText("-60s", gx + 4 * d, gb + 15 * d, t);
        c.drawText("MAX " + rate(gmax), gx + 4 * d, gt + 4 * d, t);
        t.setTextAlign(Paint.Align.RIGHT);
        c.drawText("NOW", gx + gw - 4 * d, gb + 15 * d, t);

        // ---- stats grid
        long up = SystemClock.elapsedRealtime() - born;
        String[][] cells = {
                {"SESSION \u25BC", size(totRx)}, {"SESSION \u25B2", size(totTx)}, {"PEAK \u25BC", rate(peakDl)}, {"PEAK \u25B2", rate(peakUl)},
                {"AVG \u25BC", rate(samples == 0 ? 0 : sumDl / samples)}, {"AVG \u25B2", rate(samples == 0 ? 0 : sumUl / samples)},
                {"UPTIME", clock(up)}, {"LINK", link + (pkRate > 0 ? "  " + pkRate + "pk/s" : "")}};
        float cw = (w - 36 * d) / 4f;
        for (int i = 0; i < 8; i++) {
            float cx = 18 * d + (i % 4) * cw, cy = i < 4 ? 284 * d : 316 * d;
            t.setTypeface(Typeface.create("sans-serif-condensed", Typeface.NORMAL));
            t.setLetterSpacing(0.14f);
            t.setTextSize(8f * d);
            t.setTextAlign(Paint.Align.LEFT);
            t.setColor(0xFF7384A8);
            c.drawText(cells[i][0], cx, cy, t);
            t.setTypeface(Typeface.create("monospace", Typeface.BOLD));
            t.setLetterSpacing(0f);
            t.setTextSize(i == 7 ? 8.6f * d : 10.4f * d);
            t.setColor(i % 4 < 2 && i < 4 ? WHITE : (i % 2 == 0 && i < 6 ? GOLD : (i < 6 ? CYAN : WHITE)));
            c.drawText(cells[i][1], cx, cy + 14 * d, t);
        }
        c.restore();

        // ---- corner brackets (fixed layer) and the scan line
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(2.2f * d);
        p.setColor(GOLD);
        float b = 26 * d;
        c.drawLine(r.left + 16 * d, r.top, r.left + 16 * d + b, r.top, p);
        c.drawLine(r.left, r.top + 16 * d, r.left, r.top + 16 * d + b, p);
        c.drawLine(r.right - 16 * d - b, r.bottom, r.right - 16 * d, r.bottom, p);
        c.drawLine(r.right, r.bottom - 16 * d - b, r.right, r.bottom - 16 * d, p);
        float sy = r.top + (hh - 4 * d) * ((tms % 5f) / 5f);
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, sy - 18 * d, 0, sy, 0x0038BDF8, 0x2238BDF8, Shader.TileMode.CLAMP));
        c.drawRect(r.left + 8 * d, sy - 18 * d, r.right - 8 * d, sy, p);
        p.setShader(null);
        c.restore();
    }

    private static double max(double[] v) { double m = 0; for (double x : v) if (x > m) m = x; return m; }

    private void gauge(Canvas c, float cx, float cy, float R, String label, String arrow, double v, double mx, int color, float tms) {
        float frac = (float) Math.min(1.0, Math.sqrt(Math.max(0, v) / mx));
        arc.set(cx - R, cy - R, cx + R, cy + R);
        // ticks
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeCap(Paint.Cap.BUTT);
        p.setStrokeWidth(1.2f * d);
        for (int i = 0; i <= 36; i++) {
            double a = Math.toRadians(135 + 270.0 * i / 36);
            float r1 = R + 9 * d, r2 = R + (i % 6 == 0 ? 17 : 13) * d;
            boolean lit = i / 36f <= frac;
            p.setColor(lit ? (color & 0x00FFFFFF) | 0xAA000000 : 0x33FFFFFF);
            c.drawLine(cx + (float) Math.cos(a) * r1, cy + (float) Math.sin(a) * r1, cx + (float) Math.cos(a) * r2, cy + (float) Math.sin(a) * r2, p);
        }
        // track + glow + value
        p.setStrokeCap(Paint.Cap.ROUND);
        p.setStrokeWidth(7 * d);
        p.setColor(0x22FFFFFF);
        c.drawArc(arc, 135, 270, false, p);
        if (frac > 0.005f) {
            p.setStrokeWidth(15 * d);
            p.setColor((color & 0x00FFFFFF) | 0x30000000);
            c.drawArc(arc, 135, 270 * frac, false, p);
            p.setStrokeWidth(7 * d);
            p.setColor(color);
            c.drawArc(arc, 135, 270 * frac, false, p);
            double a = Math.toRadians(135 + 270 * frac);
            float ex = cx + (float) Math.cos(a) * R, ey = cy + (float) Math.sin(a) * R;
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFFFFFFFF);
            c.drawCircle(ex, ey, 3.2f * d, p);
            p.setColor((color & 0x00FFFFFF) | 0x55000000);
            c.drawCircle(ex, ey, (6f + 2f * (float) Math.sin(tms * 5)) * d, p);
        }
        // radar sweep on the outer ring
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.6f * d);
        p.setColor((color & 0x00FFFFFF) | 0x66000000);
        arc.inset(-24 * d, -24 * d);
        c.drawArc(arc, (tms * 120f) % 360f, 26, false, p);
        // readout
        String[] s = speed(v);
        t.setTextAlign(Paint.Align.CENTER);
        t.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
        t.setLetterSpacing(0.2f);
        t.setTextSize(8.5f * d);
        t.setColor(0xFF8FA3C8);
        c.drawText(arrow + " " + label, cx, cy - 20 * d, t);
        t.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        t.setLetterSpacing(0f);
        t.setTextSize(s[0].length() > 5 ? 23 * d : 27 * d);
        t.setColor(color);
        c.drawText(s[0], cx, cy + 10 * d, t);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        t.setTextSize(10 * d);
        t.setColor(WHITE);
        c.drawText(s[1], cx, cy + 26 * d, t);
        t.setTextAlign(Paint.Align.LEFT);
    }

    private void graph(Canvas c, double[] v, double max, float gx, float gw, float gt, float gb, int color, boolean fillIt) {
        line.reset();
        area.reset();
        float lx = 0, ly = 0;
        for (int i = 0; i < N; i++) {
            float x = gx + gw * i / (N - 1f);
            float y = (float) (gb - (gb - gt) * Math.min(1.0, v[i] / max));
            if (i == 0) { line.moveTo(x, y); area.moveTo(x, gb); area.lineTo(x, y); }
            else { line.lineTo(x, y); area.lineTo(x, y); }
            lx = x; ly = y;
        }
        area.lineTo(gx + gw, gb);
        area.close();
        if (fillIt) {
            p.setStyle(Paint.Style.FILL);
            p.setShader(new LinearGradient(0, gt, 0, gb, (color & 0x00FFFFFF) | 0x77000000, (color & 0x00FFFFFF), Shader.TileMode.CLAMP));
            c.drawPath(area, p);
            p.setShader(null);
        }
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setStrokeWidth(4.5f * d);
        p.setColor((color & 0x00FFFFFF) | 0x28000000);
        c.drawPath(line, p);
        p.setStrokeWidth(1.7f * d);
        p.setColor(color);
        c.drawPath(line, p);
        p.setStyle(Paint.Style.FILL);
        p.setColor(0xFFFFFFFF);
        c.drawCircle(lx, ly, 2.4f * d, p);
    }
}
