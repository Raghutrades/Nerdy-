package com.nerdyintruder.nerdyshield;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.net.TrafficStats;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;

/** Glass "live network" card: download/upload speed, 60 s graph, session totals, gentle 3D tilt that follows the phone. */
public class StatsOverlay extends View implements SensorEventListener {
    static final int ID = 0x4e530001;
    private static final int N = 60;
    private static final int GOLD = 0xFFFFC400, CYAN = 0xFF38BDF8;

    private final float d;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG), t = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path line = new Path(), area = new Path();
    private final RectF r = new RectF();
    private final double[] dl = new double[N], ul = new double[N];
    private final Handler h = new Handler(Looper.getMainLooper());
    private final int uid = android.os.Process.myUid();
    private long lastT, lastRx, lastTx, totRx, totTx;
    private double sdl, sul, peakDl, peakUl;
    private boolean running, shown = true;
    private float tiltX, tiltY;
    private SensorManager sm;

    public StatsOverlay(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        setCameraDistance(d * 9000f);
        setAlpha(0f);
        setClickable(false);
        setFocusable(false);
    }

    void resume() {
        if (running) return;
        running = true;
        lastT = 0;
        try {
            sm = (SensorManager) getContext().getSystemService(Context.SENSOR_SERVICE);
            Sensor s = sm == null ? null : sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
            if (s != null) sm.registerListener(this, s, SensorManager.SENSOR_DELAY_UI);
        } catch (Throwable ignored) { }
        h.post(tick);
    }

    void pause() {
        running = false;
        h.removeCallbacks(tick);
        try { if (sm != null) sm.unregisterListener(this); } catch (Throwable ignored) { }
    }

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!running) return;
            sample();
            boolean want = onConnectScreen(getRootView());
            if (want != shown) {
                shown = want;
                animate().alpha(want ? 1f : 0f).setDuration(260).start();
            } else if (getAlpha() == 0f && want) {
                animate().alpha(1f).setDuration(400).start();
            }
            invalidate();
            h.postDelayed(this, 1000);
        }
    };

    /** The panel belongs to the Connect screen only: it is shown while a visible switch (the Connect pill) is on screen. */
    private static boolean onConnectScreen(View v) {
        if (v == null || v.getVisibility() != VISIBLE) return false;
        if (v instanceof CompoundButton) return v.isShown();
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) if (onConnectScreen(g.getChildAt(i))) return true;
        }
        return false;
    }

    private void sample() {
        long now = SystemClock.elapsedRealtime();
        long rx = TrafficStats.getUidRxBytes(uid), tx = TrafficStats.getUidTxBytes(uid);
        if (rx == TrafficStats.UNSUPPORTED || tx == TrafficStats.UNSUPPORTED) { rx = TrafficStats.getTotalRxBytes(); tx = TrafficStats.getTotalTxBytes(); }
        if (lastT != 0 && rx >= lastRx && tx >= lastTx) {
            double dt = (now - lastT) / 1000.0;
            if (dt > 0.2) {
                double a = (rx - lastRx) / dt, b = (tx - lastTx) / dt;
                System.arraycopy(dl, 1, dl, 0, N - 1);
                System.arraycopy(ul, 1, ul, 0, N - 1);
                dl[N - 1] = a;
                ul[N - 1] = b;
                sdl = sdl * 0.4 + a * 0.6;
                sul = sul * 0.4 + b * 0.6;
                totRx += rx - lastRx;
                totTx += tx - lastTx;
                if (a > peakDl) peakDl = a;
                if (b > peakUl) peakUl = b;
            }
        }
        lastT = now; lastRx = rx; lastTx = tx;
    }

    @Override public void onSensorChanged(SensorEvent e) {
        float x = e.values[0], y = e.values[1];
        float ty = Math.max(-7f, Math.min(7f, -x * 1.1f));
        float tx = Math.max(-6f, Math.min(6f, (y - 7.5f) * 1.0f));
        tiltY += (ty - tiltY) * 0.12f;
        tiltX += (tx - tiltX) * 0.12f;
        setRotationY(tiltY);
        setRotationX(tiltX);
    }

    @Override public void onAccuracyChanged(Sensor s, int a) { }

    @Override protected void onDetachedFromWindow() { pause(); super.onDetachedFromWindow(); }

    private static String[] speed(double b) {
        if (b < 1024) return new String[]{String.format("%.0f", b), "B/s"};
        if (b < 1048576) return new String[]{String.format("%.1f", b / 1024), "KB/s"};
        return new String[]{String.format("%.2f", b / 1048576), "MB/s"};
    }

    private static String size(long b) {
        if (b < 1024) return b + " B";
        if (b < 1048576) return String.format("%.1f KB", b / 1024.0);
        if (b < 1073741824L) return String.format("%.1f MB", b / 1048576.0);
        return String.format("%.2f GB", b / 1073741824.0);
    }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), hh = getHeight(), pad = 16 * d;
        r.set(2 * d, 2 * d, w - 2 * d, hh - 2 * d);
        // glass body
        p.setStyle(Paint.Style.FILL);
        p.setShader(new LinearGradient(0, 0, 0, hh, 0x30FFFFFF, 0x0CFFFFFF, Shader.TileMode.CLAMP));
        c.drawRoundRect(r, 20 * d, 20 * d, p);
        p.setShader(null);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.2f * d);
        p.setColor(0x44BFD8FF);
        c.drawRoundRect(r, 20 * d, 20 * d, p);
        // gold corner brackets
        p.setColor(GOLD);
        p.setStrokeWidth(2f * d);
        p.setStrokeCap(Paint.Cap.ROUND);
        c.drawLine(r.left + 14 * d, r.top, r.left + 36 * d, r.top, p);
        c.drawLine(r.left, r.top + 14 * d, r.left, r.top + 36 * d, p);
        c.drawLine(r.right - 36 * d, r.bottom, r.right - 14 * d, r.bottom, p);
        c.drawLine(r.right, r.bottom - 36 * d, r.right, r.bottom - 14 * d, p);

        // header
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        t.setLetterSpacing(0.22f);
        t.setTextSize(10 * d);
        t.setColor(CYAN);
        t.setTextAlign(Paint.Align.LEFT);
        c.drawText("LIVE NETWORK", pad, 28 * d, t);
        t.setTextAlign(Paint.Align.RIGHT);
        t.setColor(0xFFB8C4DE);
        c.drawText("NERDYSHIELD", w - pad - 12 * d, 28 * d, t);
        p.setStyle(Paint.Style.FILL);
        p.setColor(sdl + sul > 512 ? 0xFF3DDC84 : 0xFF6B7A99);
        c.drawCircle(w - pad - 3 * d, 25 * d, 3.2f * d, p);

        // big numbers
        column(c, pad, "\u25BC  DOWNLOAD", sdl, GOLD);
        column(c, w / 2f + 6 * d, "\u25B2  UPLOAD", sul, CYAN);

        // graph
        float gx = pad, gw = w - 2 * pad, gt = 104 * d, gb = 160 * d;
        double max = 10 * 1024;
        for (int i = 0; i < N; i++) { if (dl[i] > max) max = dl[i]; if (ul[i] > max) max = ul[i]; }
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1f);
        p.setColor(0x22FFFFFF);
        c.drawLine(gx, gb, gx + gw, gb, p);
        c.drawLine(gx, (gt + gb) / 2f, gx + gw, (gt + gb) / 2f, p);
        graph(c, dl, max, gx, gw, gt, gb, GOLD, true);
        graph(c, ul, max, gx, gw, gt, gb, CYAN, false);

        // footer
        t.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
        t.setLetterSpacing(0.06f);
        t.setTextSize(10.5f * d);
        t.setTextAlign(Paint.Align.LEFT);
        t.setColor(0xFFB8C4DE);
        c.drawText("SESSION  \u25BC " + size(totRx) + "   \u25B2 " + size(totTx), pad, hh - 18 * d, t);
        t.setTextAlign(Paint.Align.RIGHT);
        String[] pk = speed(peakDl);
        c.drawText("PEAK " + pk[0] + " " + pk[1], w - pad, hh - 18 * d, t);
    }

    private void column(Canvas c, float x, String label, double v, int color) {
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        t.setLetterSpacing(0.14f);
        t.setTextSize(9.5f * d);
        t.setTextAlign(Paint.Align.LEFT);
        t.setColor(0xFF9FB0D0);
        c.drawText(label, x, 50 * d, t);
        String[] s = speed(v);
        t.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        t.setLetterSpacing(0f);
        t.setTextSize(30 * d);
        t.setColor(color);
        c.drawText(s[0], x, 84 * d, t);
        float wv = t.measureText(s[0]);
        t.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        t.setTextSize(11 * d);
        t.setColor(0xFFB8C4DE);
        c.drawText(s[1], x + wv + 5 * d, 84 * d, t);
    }

    private void graph(Canvas c, double[] v, double max, float gx, float gw, float gt, float gb, int color, boolean fillIt) {
        line.reset();
        area.reset();
        for (int i = 0; i < N; i++) {
            float x = gx + gw * i / (N - 1f);
            float y = (float) (gb - (gb - gt) * Math.min(1.0, v[i] / max));
            if (i == 0) { line.moveTo(x, y); area.moveTo(x, gb); area.lineTo(x, y); }
            else { line.lineTo(x, y); area.lineTo(x, y); }
        }
        area.lineTo(gx + gw, gb);
        area.close();
        if (fillIt) {
            p.setStyle(Paint.Style.FILL);
            p.setShader(new LinearGradient(0, gt, 0, gb, (color & 0x00FFFFFF) | 0x66000000, (color & 0x00FFFFFF), Shader.TileMode.CLAMP));
            c.drawPath(area, p);
            p.setShader(null);
        }
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.8f * d);
        p.setStrokeJoin(Paint.Join.ROUND);
        p.setColor(color);
        c.drawPath(line, p);
    }
}
