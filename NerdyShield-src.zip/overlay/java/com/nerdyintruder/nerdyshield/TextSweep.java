package com.nerdyintruder.nerdyshield;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;
import android.text.Spanned;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewTreeObserver;
import android.widget.EditText;
import android.widget.TextView;

import java.util.regex.Pattern;

/** Rewrites visible old-brand words in any screen of the app, including text the app builds in code. */
final class TextSweep {
    private static final Pattern BROWSER = Pattern.compile("\\bTor Browser\\b"), PROJ = Pattern.compile("\\b(?:The )?Tor Project\\b"),
            ORBOT = Pattern.compile("\\bOrbot\\b"), TORLINE = Pattern.compile("(?m)^[ \\t]*Tor[ \\t]*$"), TOR = Pattern.compile("\\bTor\\b");
    private static final int KEY = 0x4e530002;

    private TextSweep() { }

    static String fix(String s) {
        if (s == null || s.length() == 0 || s.length() > 400) return null;
        if (s.indexOf("http") >= 0 || s.indexOf(".onion") >= 0 || s.indexOf("torproject") >= 0 || s.indexOf('/') >= 0) return null;
        String[] lines = s.split("\\n", -1);
        StringBuilder out = new StringBuilder();
        for (int i = 0; i < lines.length; i++) {
            String ln = lines[i], tr = ln.trim();
            if (tr.equals("Tor") || tr.equals("TOR")) ln = ln.replace(tr, "Core");
            else if (tr.equals("Orbot")) ln = ln.replace(tr, "Shield");
            else {
                ln = BROWSER.matcher(ln).replaceAll("a private browser");
                ln = PROJ.matcher(ln).replaceAll("NerdyShield");
                ln = ORBOT.matcher(ln).replaceAll("NerdyShield");
                ln = TOR.matcher(ln).replaceAll("NerdyShield");
            }
            if (i > 0) out.append('\n');
            out.append(ln);
        }
        String o = out.toString();
        return o.equals(s) ? null : o;
    }

    static void sweep(View v) {
        if (v instanceof EditText) return;
        if (v instanceof TextView) {
            TextView tv = (TextView) v;
            CharSequence cs = tv.getText();
            if (cs != null && !(cs instanceof Spanned)) {
                String f = fix(cs.toString());
                if (f != null) tv.setText(f);
            }
        }
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) sweep(g.getChildAt(i));
        }
    }

    static void attach(final Activity a) {
        try {
            final View root = a.getWindow().getDecorView();
            if (root.getTag(KEY) != null) return;
            root.setTag(KEY, Boolean.TRUE);
            final Handler h = new Handler(Looper.getMainLooper());
            final Runnable run = new Runnable() { @Override public void run() { try { sweep(root); } catch (Throwable ignored) { } } };
            root.getViewTreeObserver().addOnGlobalLayoutListener(new ViewTreeObserver.OnGlobalLayoutListener() {
                @Override public void onGlobalLayout() { h.removeCallbacks(run); h.postDelayed(run, 120); }
            });
            h.post(run);
        } catch (Throwable ignored) { }
    }
}
