package com.nerdyintruder.nerdyshield;

import android.content.Context;
import android.os.Build;
import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;

/** Saves the last crash to a file so the next launch can show it on screen (no computer needed). */
final class CrashLog {
    private CrashLog() { }

    static File file(Context c) { return new File(c.getFilesDir(), "ns_crash.txt"); }

    static void install(final Context c) {
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
            @Override public void uncaughtException(Thread t, Throwable e) {
                try { record(c, e, "crash in thread " + t.getName()); } catch (Throwable ignored) { }
                if (prev != null) prev.uncaughtException(t, e);
            }
        });
    }

    static void record(Context c, Throwable e, String where) {
        try {
            String s = where + "\nAndroid " + Build.VERSION.RELEASE + " (API " + Build.VERSION.SDK_INT + ") " + Build.MANUFACTURER + " " + Build.MODEL
                    + "\n\n" + Log.getStackTraceString(e);
            if (s.length() > 6000) s = s.substring(0, 6000);
            FileOutputStream o = new FileOutputStream(file(c));
            o.write(s.getBytes("UTF-8"));
            o.close();
        } catch (Throwable ignored) { }
    }

    static String read(Context c) {
        try {
            File f = file(c);
            if (!f.exists()) return null;
            FileInputStream in = new FileInputStream(f);
            byte[] b = new byte[(int) f.length()];
            int n = in.read(b);
            in.close();
            return n > 0 ? new String(b, 0, n, "UTF-8") : null;
        } catch (Throwable t) { return null; }
    }

    static void clear(Context c) { try { file(c).delete(); } catch (Throwable ignored) { } }
}
