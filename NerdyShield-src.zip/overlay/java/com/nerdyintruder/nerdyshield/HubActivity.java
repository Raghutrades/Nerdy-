package com.nerdyintruder.nerdyshield;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;

/** The NerdyShield home: neat menus (Home, Safety, About, Build) in one offline page. "Open the Shield" launches the main screen. */
public class HubActivity extends Activity {
    private WebView wv;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        w.setStatusBarColor(Color.parseColor("#FFF6CC"));
        w.setNavigationBarColor(Color.parseColor("#FFFFFF"));
        w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | (android.os.Build.VERSION.SDK_INT >= 26 ? View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR : 0));
        wv = new WebView(this);
        wv.setBackgroundColor(Color.parseColor("#FFF6CC"));
        setContentView(wv);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setBlockNetworkLoads(true);
        wv.addJavascriptInterface(new ShieldBridge(this, null), "NS");
        String route = getIntent().getStringExtra("route");
        wv.loadUrl("file:///android_asset/shield/hub.html#" + (route == null ? "home" : route));
    }

    @Override protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        String route = i.getStringExtra("route");
        if (route != null && wv != null) wv.evaluateJavascript("location.hash='" + route.replaceAll("[^a-z]", "") + "'", null);
    }


    @Override public void onBackPressed() {
        if (wv != null && wv.canGoBack()) wv.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() { if (wv != null) { wv.destroy(); wv = null; } super.onDestroy(); }
}
