package com.nerdyintruder.nerdyshield;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.net.Uri;
import android.os.Build;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import java.security.MessageDigest;

/** The only door between the offline NerdyShield pages and Android. Pages cannot touch the network (it is blocked in the WebView). */
public class ShieldBridge {
    // class names are rewritten at build time to the real launcher activity of the base app
    static final String SHIELD_MAIN = "org.torproject.android.OrbotActivity";
    static final String SHIELD_ONION = "org.torproject.android.ui.v3onionservice.OnionServiceActivity";
    static final String SHIELD_AUTH = "org.torproject.android.ui.v3onionservice.clientauth.ClientAuthActivity";

    private final Activity act;
    private final Runnable onDone;
    private final SharedPreferences sp;

    ShieldBridge(Activity a, Runnable onDone) {
        this.act = a;
        this.onDone = onDone;
        this.sp = a.getSharedPreferences("nerdyshield", Context.MODE_PRIVATE);
    }

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("nerdyshield", Context.MODE_PRIVATE); }

    static void openMain(Activity a) { openScreen(a, SHIELD_MAIN); }

    static void openScreen(Activity a, String cls) {
        try {
            Intent i = new Intent().setClassName(a.getPackageName(), cls);
            a.startActivity(i);
        } catch (Throwable t) {
            Toast.makeText(a, "Could not open that screen: " + t.getClass().getSimpleName(), Toast.LENGTH_LONG).show();
        }
    }

    @JavascriptInterface public void done() { if (onDone != null) act.runOnUiThread(onDone); }

    @JavascriptInterface public void open(final String what) {
        act.runOnUiThread(new Runnable() { public void run() {
            if ("shield".equals(what)) openScreen(act, SHIELD_MAIN);
            else if ("onion".equals(what)) openScreen(act, SHIELD_ONION);
            else if ("auth".equals(what)) openScreen(act, SHIELD_AUTH);
            else if ("replay".equals(what)) {
                Intent i = new Intent(act, SplashActivity.class).putExtra("replay", true);
                act.startActivity(i);
            }
        }});
    }

    /** Only a short allow-list of links may leave the app, and only through the user's own browser. */
    @JavascriptInterface public void link(final String url) {
        if (url == null) return;
        boolean ok = url.startsWith("https://www.instagram.com/nerdyintruder");
        if (!ok) return;
        act.runOnUiThread(new Runnable() { public void run() {
            try { act.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); } catch (Throwable ignored) { }
        }});
    }

    @JavascriptInterface public void copy(final String text) {
        act.runOnUiThread(new Runnable() { public void run() {
            ClipboardManager cm = (ClipboardManager) act.getSystemService(Context.CLIPBOARD_SERVICE);
            if (cm != null) cm.setPrimaryClip(ClipData.newPlainText("NerdyShield", text));
            Toast.makeText(act, "Copied", Toast.LENGTH_SHORT).show();
        }});
    }

    // ---- settings ----
    @JavascriptInterface public int getStyle() { return sp.getInt("style", 0); }
    @JavascriptInterface public void setStyle(int s) { sp.edit().putInt("style", s).apply(); }
    @JavascriptInterface public boolean getDirect() { return sp.getBoolean("direct", true); }
    @JavascriptInterface public void setDirect(boolean v) { sp.edit().putBoolean("direct", v).apply(); }
    @JavascriptInterface public boolean getSound() { return sp.getBoolean("sound", true); }
    @JavascriptInterface public void setSound(boolean v) { sp.edit().putBoolean("sound", v).apply(); }


    /** JSON with this build's identity, so you can see exactly what you are running. */
    @JavascriptInterface public String info() {
        String ver = "?", sha = "unknown";
        long code = 0;
        try {
            PackageManager pm = act.getPackageManager();
            Signature[] sigs;
            PackageInfo pi;
            if (Build.VERSION.SDK_INT >= 28) {
                pi = pm.getPackageInfo(act.getPackageName(), PackageManager.GET_SIGNING_CERTIFICATES);
                sigs = pi.signingInfo.getApkContentsSigners();
            } else {
                pi = pm.getPackageInfo(act.getPackageName(), PackageManager.GET_SIGNATURES);
                sigs = pi.signatures;
            }
            ver = pi.versionName == null ? "?" : pi.versionName;
            code = Build.VERSION.SDK_INT >= 28 ? pi.getLongVersionCode() : pi.versionCode;
            byte[] h = MessageDigest.getInstance("SHA-256").digest(sigs[0].toByteArray());
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < h.length; i++) { if (i > 0) sb.append(':'); sb.append(String.format("%02X", h[i])); }
            sha = sb.toString();
        } catch (Throwable ignored) { }
        return "{\"pkg\":\"" + act.getPackageName() + "\",\"ver\":\"" + ver.replace("\"", "") + "\",\"code\":" + code
                + ",\"sha\":\"" + sha + "\",\"android\":" + Build.VERSION.SDK_INT + "}";
    }
}
