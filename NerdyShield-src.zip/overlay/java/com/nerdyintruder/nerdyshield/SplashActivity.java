package com.nerdyintruder.nerdyshield;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.WindowManager;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;

/** Launcher activity. Its own full-screen window: plays the cinematic intro (animation + score), then hands over to the NerdyShield main screen (or the hub). */
public class SplashActivity extends Activity {
    private WebView wv;
    private MediaPlayer mp;
    private boolean left = false;
    private final Handler h = new Handler(Looper.getMainLooper());

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        goEdgeToEdge();
        wv = new WebView(this);
        wv.setBackgroundColor(Color.parseColor("#02040A"));
        setContentView(wv);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setBlockNetworkLoads(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        final ShieldBridge br = new ShieldBridge(this, new Runnable() { public void run() { leave(); } });
        wv.addJavascriptInterface(br, "NS");
        wv.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView v, String url) {
                startScore();                                   // music first...
                v.evaluateJavascript("window.go&&window.go()", null); // ...then the picture, so they start together
            }
        });
        wv.loadUrl("file:///android_asset/shield/splash.html");
        h.postDelayed(new Runnable() { public void run() { leave(); } }, 11000); // safety net
    }

    /** Draws behind the status bar, the navigation bar and the camera cut-out, so the intro fills the whole screen (no borders). */
    private void goEdgeToEdge() {
        android.view.Window w = getWindow();
        w.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN | WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
        w.setStatusBarColor(Color.TRANSPARENT);
        w.setNavigationBarColor(Color.TRANSPARENT);
        w.setBackgroundDrawable(new android.graphics.drawable.ColorDrawable(Color.parseColor("#02040A")));
        if (Build.VERSION.SDK_INT >= 28) {
            WindowManager.LayoutParams lp = w.getAttributes();
            lp.layoutInDisplayCutoutMode = Build.VERSION.SDK_INT >= 30
                    ? WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                    : WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
            w.setAttributes(lp);
        }
        hideBars();
    }

    private void hideBars() {
        android.view.Window w = getWindow();
        if (Build.VERSION.SDK_INT >= 30) {
            w.setDecorFitsSystemWindows(false);
            android.view.WindowInsetsController c = w.getInsetsController();
            if (c != null) {
                c.hide(android.view.WindowInsets.Type.systemBars());
                c.setSystemBarsBehavior(android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            w.getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_FULLSCREEN
                    | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        }
    }

    @Override public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideBars();
    }

    /** Plays assets/shield/intro.ogg through MediaPlayer (works with the phone's media volume; silent if the intro sound is switched off). */
    private void startScore() {
        if (mp != null || !ShieldBridge.prefs(this).getBoolean("sound", true)) return;
        try {
            File f = new File(getCacheDir(), "intro.ogg");
            if (!f.exists() || f.length() == 0) {
                InputStream in = getAssets().open("shield/intro.ogg");
                OutputStream out = new FileOutputStream(f);
                byte[] buf = new byte[16384];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                out.close();
                in.close();
            }
            mp = new MediaPlayer();
            mp.setAudioStreamType(AudioManager.STREAM_MUSIC);
            mp.setDataSource(f.getAbsolutePath());
            mp.setVolume(0.9f, 0.9f);
            mp.prepare();
            mp.start();
        } catch (Throwable t) {
            releaseScore();
        }
    }

    private void releaseScore() {
        if (mp != null) {
            try { mp.stop(); } catch (Throwable ignored) { }
            try { mp.release(); } catch (Throwable ignored) { }
            mp = null;
        }
    }

    private void leave() {
        if (left) return;
        left = true;
        boolean replay = getIntent().getBooleanExtra("replay", false);
        boolean direct = ShieldBridge.prefs(this).getBoolean("direct", true);
        if (replay) { finish(); return; }
        if (direct) ShieldBridge.openMain(this);
        else startActivity(new Intent(this, HubActivity.class));
        finish();
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
    }

    @Override protected void onDestroy() {
        h.removeCallbacksAndMessages(null);
        releaseScore();
        if (wv != null) { wv.destroy(); wv = null; }
        super.onDestroy();
    }
}
