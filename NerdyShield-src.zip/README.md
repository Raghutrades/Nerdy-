# NerdyShield

NerdyShield, by Raghu (@NerdyIntruder): a private, one-tap network shield for Android, with per-app routing, bridges and onion services.

## What this build does
- **Name and look:** NerdyShield everywhere in the app (launcher, screens, notifications, About, shortcuts). Old logos and the mascot are replaced by the bat; palette is blue, teal or ink with gold.
- **Cinematic launch:** the app opens in its own full-screen window with a ~7 s intro (light beam, particles, the bat drawing itself, an impact hit, letter-by-letter title) and an original synthesised score, then slides into the main screen. Tap to skip.
- **Donate removed:** every Donate row, button, menu item and preference is hidden.
- **Same behaviour:** Connect, Choose apps, bridges, exit, onion services work exactly as before.
- **Extras:** long-press the icon for About me, Stay safe, Build info. The hub also has an Open-source licences page.

## Build (phone friendly)
1. Private GitHub repo. Upload at the root: `NerdyShield-src.zip`, `Orbot_apk.part00`, `Orbot_apk.part01` (each under 25 MB). Optional `raghu.jpg`.
2. Add `.github/workflows/build-shield.yml`.
3. **Actions > Build NerdyShield APK > Run workflow**, pick a palette.
4. Download `NerdyShield.apk` from **Releases > latest**.

The build refuses to run if the base APK is not signed by its original developer.

## Intro sound
`tools/sound.py` synthesises the score (pure Python, no samples). The ready file is `overlay/assets/shield/intro.ogg`. Switch it off in the hub (Home > Intro sound).

## Licences (important)
NerdyShield is built on open-source software under the BSD 3-Clause licence, which requires the copyright and licence notice to ship with the app. The build copies it into the About screen and the hub's licences page. Keep it.

## Security
Signing key: `keystore/nerdyshield.jks` (password `nerdyshield`). Keep the repo private.
